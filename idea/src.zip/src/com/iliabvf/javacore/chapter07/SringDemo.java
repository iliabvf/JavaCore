package com.iliabvf.javacore.chapter07;

// Продемонстрировать применение символьных строк
class StringDemo {


    public static void main(String args[]) {
        String strOb1 = "Первая строка";
        String strOb2 = "Вторая строка";
        String strObЗ = strOb1 + "  и " + strOb2;
        System.out.println(strOb1);
        System.out.println(strOb2);
        System.out.println(strObЗ);
    }
}