package com.iliabvf.javacore.chapter04;

public class While {

    public static void main(String[] args) {
        // Продемонстрировать применение оператора цикла while
        int n = 10;
        while (n > 0) {
            System.out.println("тaкт " + n);
            n--;
        }
    }

}
