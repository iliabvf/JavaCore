package com.iliabvf.javacore.chapter04;

public class DoWhile {

    public static void main(String[] args) {
        // Продемонстрировать применение  оператора  цикла do-while
        int n = 10;
        do {
            System.out.println("тaкт" + n);
            n--;
        } while (n > 0) ;

        }
    }
