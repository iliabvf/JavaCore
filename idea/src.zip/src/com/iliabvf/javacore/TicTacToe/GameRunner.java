package com.iliabvf.javacore.TicTacToe;

// главный класс приложения, содержащий метод main
public class GameRunner {
    public static void main(String[] args) {
        GameLogic gameLogic = new GameLogic();
        gameLogic.startGame();
    }
}
