package com.iliabvf.javacore.chapter02;

/* Это еще  один короткий пример программы . Присвоить исходному файлу имя "Exaiaple2.java" */ 
class Example2 { 
	public static void main (String args[]) { 
		int num; //в  этой  строке кода объявляется переменная с  именем num 
		num = 100; // в  этой  строке кода переменной nwn 11 присваивается значение 100 
		System.out.println("Этo переменная num: " + num); 
		num = num * 2; 
		System.out.print("Знaчeниe переменной num  *  2 равно"); 
		System.out.println(num);
	}
}