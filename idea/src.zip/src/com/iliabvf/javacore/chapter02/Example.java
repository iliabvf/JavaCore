package com.iliabvf.javacore.chapter02;

/* Это простая программа на  Java. Глава 2. К раткий  обзор Java 61 Присвоить исходному  файлу имя "Example.java" */ 
class  Example { 
// Эта программа начинается с  вызова метода шain() 
public static void main (String args[])   {
	System.out.println("Пpocтaя программа на  Java.");
}	
}