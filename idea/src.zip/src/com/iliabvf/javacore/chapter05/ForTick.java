package com.iliabvf.javacore.chapter05;

public class ForTick {

    // Продемонстрировать применение  оператора цикла for
    public static void main (String args[] ) {
        int n;
        for (n = 10; n > 0; n--)
            System.out.println("тaкт" + n);
    }
}
