package com.iliabvf.javacore.chapter03;

// Вычислить площадь круга 
class Area { 
	public static void main (String args[]) { 
		double  pi, r, a;
		r = 10.8;
		pi = 3.1416;
		a = pi *  r  * r;
		// радиус окружности
		// приблизительное значение числа пи r;
		// вычислить площадь круга
		System.out.println("Плoщaдь круга равна " + a);
	}
}