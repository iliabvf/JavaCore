package com.iliabvf.javacore.chapter03;

// Продемонстрировать применение типа данных char 
class CharDemo { 
	public static void main (String args[])   { 
		char ch1, ch2;
		ch1 = 88; // код символа Х 
		ch2 = 'Y';
		System.out.print("chl и  ch2: ");
		System.out.println(ch1 +  "  "  +  ch2);
	}
}
