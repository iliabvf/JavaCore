package com.iliabvf.javacore.chapter03;

// Усовершенствованная версия предыдущей программы 
class AutoArray { 
	public static void main (String args[])   { 
		int month_days[] = {   31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; 
		System.out.println("B  апреле"+ month_days[3] +  "дней.") ; 
	}
}